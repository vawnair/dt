from discord.ext.commands import CommandNotFound
from discord.ext import commands, tasks
from utils import *
import aiosqlite
import requests
import discord
import spur
import json
import os

async def dequeue(claimed):
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue ORDER BY position")
    rows = await cursor.fetchone()
    await cursor.close()
    if rows is None:
      await linux('/root/dtsniper/config.toml', 1,
                  f'mainToken = "{your_own_token}"\n')
    discord_id = rows[0]
    claims_left = rows[2]
    total_claims = rows[3]
    user = bot.get_user(int(discord_id))
    if int(claims_left) + 1 < int(total_claims):
      await db.execute(
        "UPDATE queue SET queue_amount = queue_amount +1 WHERE position = (SELECT min(position) FROM queue)"
      )
      await db.commit()
      try:
        await user.send(f"Successfully claimed {claimed}")
      except:
        pass
    elif int(claims_left) + 1 >= int(total_claims):
      try:
        await user.send(custom_dm_message)
      except Exception as e:
        await log(f"Error", f"Could not send dm to {user} ({discord_id})\n{e}")
      await db.execute(
        "DELETE FROM queue WHERE position = (SELECT min(position) FROM queue)")
      await db.commit()
      async with aiosqlite.connect("q.db") as db:
        cursor = await db.execute(
          "SELECT position FROM queue ORDER BY position")
        rows = await cursor.fetchall()
        await cursor.close()
        rows = [x[0] for x in rows]
        i = 0
        for row in rows:
          i += 1
          await db.execute("UPDATE queue SET position = ? WHERE position = ?",
                           (i, row))
          await db.commit()
      async with aiosqlite.connect("q.db") as db:
        cursor = await db.execute("SELECT * FROM queue ORDER BY position")
        row = await cursor.fetchone()
        token = row[1]
        await linux('/root/dtsniper/config.toml', 1,
                    f'mainToken = "{token}"\n')


async def linux(file, line, text):
  count = 0
  log_chnl = bot.get_channel(int(log_channel))
  embed = discord.Embed(title="Replacing token",
                        description="",
                        color=0x0D95F3)
  msg = await log_chnl.send(embed=embed)
  for vps in vps_list:
    count += 1
    try:
      ip = vps["ip"]
      username = vps["username"]
      password = vps["password"]
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      lines = shell.open(file, 'r').readlines()
      lines[line] = text
      out = shell.open(file, 'w')
      out.writelines(lines)
      out.close()
      shell.run(['screen', '-XS', 'dtsniper', 'quit'],
                allow_error=True).output.decode()
      shell.run([
        'screen', '-S', 'dtsniper', '-dm', 'bash', '-c',
        'cd /root/dtsniper/; ./dtsniper'
      ],
                allow_error=True).output.decode()
      shell.run(['screen', '-ls'], allow_error=True).output.decode()
      embed.add_field(name=f"VPS {count}",
                      value=f"`Successfully replaced token`",
                      inline=False)
      await msg.edit(embed=embed)
    except Exception as e:
      embed.add_field(name=f"VPS {count}", value=f"`{e}`", inline=False)
      await msg.edit(embed=embed)


bot = commands.Bot(command_prefix=prefix,
                   case_insensitive=True,
                   intents=discord.Intents.all(),
                   help_command=None)


@bot.event
async def on_ready():
  update_queue.start()
  check_tokens.start()
  activity = discord.Activity(type=discord.ActivityType.watching,
                              name="Make ticket to buy / ask more 📨")
  await bot.change_presence(status=discord.Status.dnd, activity=activity)
  print(
    f"{bot.user} logged in\nMember count: {len(bot.users)}\nFirst time setup {prefix}start"
  )


@bot.listen('on_message')
async def on_message(message):
  embeds = message.embeds
  if len(embeds) != 1: return
  embed = embeds[0]
  emb_dict = embed.to_dict()
  if "title" not in emb_dict: return
  if message.author.bot and "Thanks for the nitro hehe" in emb_dict["title"]:
    channel = bot.get_channel(int(success_channel_id))
    delay = emb_dict["fields"][1]["value"]
    type = emb_dict["fields"][0]["value"]
    if "Classic" in type or 'Basic' in type:
      msg = await channel.send(
        f"{classic_emoji} Successfully Claimed {type} in {delay} {claim_ping_id}"
      )
      await msg.add_reaction("<a:boomclaim:1078043990877810871>")
    else:
      msg = await channel.send(
        f"{boost_emoji} Successfully Claimed {type} in {delay} {claim_ping_id}"
      )
      await msg.add_reaction("<a:boomclaim:1078043990877810871>")
    try:
      nitroinfo = bot.get_channel(int(totalsnipeschannel))
      mesg = await nitroinfo.fetch_message(int(totalsnipesmessage))
      embeds = mesg.embeds
      embed = embeds[0]
      emb_dict = embed.to_dict()
      description = emb_dict["description"]
      claims = description.split("`")[1]
      newdescription = f"There already been sniped a total of `{int(claims) + 1}` Nitro."
      newemb = discord.Embed(title="Total Claims",
                             description=newdescription,
                             color=0x0D95F3)
      await mesg.edit(embed=newemb)
    except Exception as e:
      await log("Error", f"Could not edit total claims message\n{e}")
      print(e)
    await dequeue(type)
  await bot.process_commands(message)


@tasks.loop(seconds=15)
async def update_queue():
  try:
    queuechnl = bot.get_channel(int(queue_channel_id))
    queuemsg = await queuechnl.fetch_message(int(queue_message_id))
    embeds = queuemsg.embeds
    embed = embeds[0]
    emb_dict = embed.to_dict()
    new_description = ""
    async with aiosqlite.connect("q.db") as db:
      cursor = await db.execute("SELECT * FROM queue ORDER BY position")
      rows = await cursor.fetchall()
      row_count = 0
      total = 0
      first = True
      for row in rows:
        row_count += 1
        user = bot.get_user(int(row[0]))
        if first:
          first = False
          new_description += f"> {row_count}. <@{row[0]}> = {row[2]}/{row[3]} {currently_claiming_emoji}\n"
        else:
          new_description += f"> {row_count}. <@{row[0]}> = {row[2]}/{row[3]} {currently_waiting_emoji}\n"
        total += int(row[3])
    embed.description = new_description
    embed.set_footer(text=f"{len(rows)} people in queue | {total} total")
    await queuemsg.edit(embed=embed)
  except Exception as e:
    await log("Error in update queue", f"**{e}**")


@tasks.loop(hours=1)
async def check_tokens():
  async with aiosqlite.connect('q.db') as db:
    cursor = await db.execute("SELECT * FROM queue")
    rows = await cursor.fetchall()
    if len(rows) == 0: return
    for row in rows:
      discord_id = row[0]
      token = row[1]
      headers = {'Authorization': token, 'Content-Type': 'application/json'}
      r = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
      if r.status_code == 401:
        user = bot.get_user(int(discord_id))
        if remove_invalid_tokens:
          await db.execute("DELETE FROM queue WHERE discord_id = ?",
                           (discord_id, ))
          await db.commit()
          await log(
            "Invalid Token",
            f"Removing token from database\nMember: **<@{discord_id}>**\nToken: **{token}**"
          )
          try:
            await user.send(
              f"Your token ending in `{token[-5:]}` has been removed from the queue because it was invalid.\nPlease contact a staff member with your new token."
            )
          except Exception as e:
            await log(f"Error",
                      f"Could not send dm to {user} ({discord_id})\n{e}")
        else:
          try:
            await user.send(
              f"Your token ending in `{token[-5:]}` is invalid.\nPlease contact a staff member with your new token."
            )
          except Exception as e:
            await log(f"Error",
                      f"Could not send dm to {user} ({discord_id})\n{e}")


@bot.command()
async def queue(ctx, member: discord.Member, amount, token):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  try:
    headers = {'Authorization': token, 'Content-Type': 'application/json'}
    r = json.loads(
      requests.get('https://discord.com/api/v9/users/@me',
                   headers=headers).text)
    async with aiosqlite.connect("q.db") as db:
      cursor = await db.execute("SELECT * FROM queue ORDER BY position")
      rows = await cursor.fetchall()
      await cursor.close()
      await db.execute(
        "INSERT INTO queue (discord_id, token, queue_amount, total_claims, position) VALUES (?, ?, ?, ?, (SELECT IFNULL(MAX(position) + 1, 1) FROM queue))",
        (member.id, token, 0, amount))
      await db.commit()
      if len(rows) == 0:
        await linux('/root/dtsniper/config.toml', 1,
                    f'mainToken = "{token}"\n')
      await update_positions()
      await log(
        "Queue",
        f"Added to queue\nMember: **{member}** ({member.id})\nToken: **{token}**\nClaims: **{amount}**"
      )
  except Exception as e:
    embed = discord.Embed(title=":x: Unauthorized error!",
                          description="Please pass a valid discord token.")
    await ctx.send(embed=embed)


@bot.command()
async def delete(ctx, discordid):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  async with aiosqlite.connect("q.db") as db:
    try:
      member = await bot.fetch_user(discordid)
      await db.execute("DELETE FROM queue WHERE discord_id = ?", (member.id, ))
      await db.commit()
    except:
      await db.execute("DELETE FROM queue WHERE discord_id = ?", (discordid, ))
      await db.commit()
    await update_positions()
    emb = discord.Embed(title=f"{member} has been removed from the queue!",
                        description="",
                        colour=0xFF0000)
    await ctx.send(embed=emb)


@bot.command()
async def addclaims(ctx, member: discord.Member, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  if not amount.isdigit():
    await ctx.send("Please enter a number")
    return
  async with aiosqlite.connect("q.db") as db:
    await db.execute(
      "UPDATE queue SET total_claims = total_claims + ? WHERE discord_id = ?",
      (amount, member.id))
    await db.commit()
    await log("Added Claims", f"{amount} claims added to {member}")


@bot.command()
async def removeclaims(ctx, member: discord.Member, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  if not amount.isdigit():
    await ctx.send("Please enter a number")
    return
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue WHERE discord_id = ?",
                              (member.id, ))
    rows = await cursor.fetchone()
    total_claims = rows[3]
    if int(total_claims) - int(amount) < 1:
      await db.execute("DELETE FROM queue WHERE discord_id = ?", (member.id, ))
      await db.commit()
      await update_positions()
      await log("Deleted User", f"{member} has been deleted from the queue")
    else:
      await db.execute(
        "UPDATE queue SET total_claims = total_claims - ? WHERE discord_id = ?",
        (amount, member.id))
      await db.commit()
      await log("Removed Claims", f"{amount} claims removed from {member}")


@bot.command()
async def update(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue ORDER BY position")
    row = await cursor.fetchone()
    token = row[1]
    await linux('/root/dtsniper/config.toml', 1, f'mainToken = "{token}"\n')


@bot.command()
async def position(ctx):
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue ORDER BY position")
    rows = await cursor.fetchall()
    if not any(ctx.author.id in row for row in rows):
      embed = discord.Embed(title="Queue Position",
                            description="You're not in the queue!",
                            color=0x00ff00)
      await ctx.send(embed=embed)
      return
    total = 0
    claims = 0
    for row in rows:
      if row[0] == ctx.author.id:
        break
      else:
        total += int(row[3])
        claims += int(row[2])
    remaining = total - claims
    embed = discord.Embed(
      title="Queue Position",
      description=f"Position: **{row[4]}**\nClaims left: **{remaining}**",
      color=0x00ff00)
    await ctx.send(embed=embed)


@bot.command()
async def move(ctx, member: discord.Member, position):
  if not await id_check(ctx.author.id):
    return
  await ctx.message.delete()
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue ORDER BY position")
    rows = await cursor.fetchall()
    for row in rows:
      if not any(member.id in row for row in rows):
        await ctx.send(f"{member} is not in the queue!")
        return
      elif row[0] == member.id:
        current_row = row[4]
        break
    if current_row == position:
      await log("Move", f"{member} is already in position {position}")
      return
    if int(position) > len(rows) or int(position) < 1:
      await log("Move", f"Position has to be between 1 and {len(rows)}")
    else:
      await db.execute(
        "UPDATE queue SET position = position + 1 WHERE position >= ? AND position < ?",
        (position, current_row))
      await db.execute(
        "UPDATE queue SET position = position - 1 WHERE position <= ? AND position > ?",
        (position, current_row))
      await db.execute("UPDATE queue SET position = ? WHERE discord_id = ?",
                       (position, member.id))
      await db.commit()
      await log(
        "Move",
        f"Member **{member}** moved\nNew Position: **{position}**\nOld Position: **{current_row}**"
      )
    await update_positions()
    if rows[0][0] == member.id or int(position) == 1:
      cursor = await db.execute("SELECT * FROM queue ORDER BY position")
      row = await cursor.fetchone()
      user = await bot.fetch_user(row[0])
      token = row[1]
      try:
        await linux('/root/dtsniper/config.toml', 1,
                    f'mainToken = "{token}"\n')
        await log(
          "Main Token",
          f"Main token updated\nMember: **{user}**\nToken Ending: **{token[-5:]}**"
        )
      except:
        await log(
          "Main Token",
          f"Main token update failed\nMember: **{user}**\nToken Ending: **{token[-5:]}**"
        )


@bot.command()
async def replacetoken(ctx, member: discord.Member, token):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT * FROM queue ORDER BY position")
    row = await cursor.fetchall()
    await db.execute("UPDATE queue SET token = ? WHERE discord_id = ?",
                     (token, member.id))
    await db.commit()
    if row[0][0] == member.id:
      await linux('/root/dtsniper/config.toml', 1, f'mainToken = "{token}"\n')
    await log(f"Token replaced", f"{member}'s token has been replaced")


@bot.command()
async def screen(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  count = 0
  embed = discord.Embed(title="Screen list", description="", color=0x00ff00)
  log_chnl = bot.get_channel(int(log_channel))
  msg = await log_chnl.send(embed=embed)
  for vps in vps_list:
    count += 1
    try:
      ip = vps['ip']
      username = vps['username']
      password = vps['password']
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      out = shell.run(['screen', '-ls']).output.decode('utf-8')
      embed.add_field(
        name=f"VPS {count}",
        value=f"`{shell.run(['screen', '-ls']).output.decode('utf-8')}`",
        inline=True)
      await msg.edit(embed=embed)
    except Exception as e:
      embed.add_field(name=f"VPS {count}", value=f"`{e}`", inline=True)
      await msg.edit(embed=embed)


@bot.command()
@commands.has_permissions(administrator=True)
async def invites(ctx):
  if not await id_check(ctx.author.id):
    return
  embed = discord.Embed(title="DT Invite list", description="", color=0x00ff00)
  count = 0
  invites = []
  for vps in vps_list:
    count += 1
    try:
      ip = vps["ip"]
      username = vps["username"]
      password = vps["password"]
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      invites.append(
        shell.run(['cat', '/root/dtsniper/invites.txt'],
                  allow_error=True).output.decode())
      shell.run(['rm', '/root/dtsniper/invites.txt'], allow_error=True)
      shell.run(['touch', '/root/dtsniper/invites.txt'], allow_error=True)
      shell.run(['chmod', '777', '/root/dtsniper/invites.txt'],
                allow_error=True)
    except Exception as e:
      await log(f"VPS {count}: {e}")
      continue
    with open("invites.txt", "w") as f:
      f.write("\n".join(invites))
    embed.add_field(name=f"VPS {count}", value=f"{invites}", inline=True)
    await ctx.send(file=discord.File("invites.txt"))


@bot.command()
async def dtsniper(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  count = 0
  embed = discord.Embed(title="DT Sniper list", description="", color=0x00ff00)
  log_chnl = bot.get_channel(int(log_channel))
  msg = await log_chnl.send(embed=embed)
  for vps in vps_list:
    count += 1
    try:
      ip = vps['ip']
      username = vps['username']
      password = vps['password']
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      processes = shell.run(['ps', 'aux'], allow_error=True)
      processes = processes.output.decode("utf-8").split("\n")
      for process in processes:
        if "./dtsniper" not in process:
          running = False
        else:
          running = True
          break
      if running:
        embed.add_field(name=f"VPS {count}", value=f"`Running`", inline=True)
        await msg.edit(embed=embed)
      else:
        shell.run(['screen', '-XS', 'dtsniper', 'quit'],
                  allow_error=True).output.decode()
        shell.run([
          'screen', '-S', 'dtsniper', '-dm', 'bash', '-c',
          'cd /root/dtsniper/; ./dtsniper'
        ],
                  allow_error=True)
        embed.add_field(name=f"VPS {count}",
                        value=f"`DT Started`",
                        inline=True)
        await msg.edit(embed=embed)
    except Exception as e:
      embed.add_field(name=f"VPS {count}", value=f"`{e}`", inline=True)
      await msg.edit(embed=embed)


@bot.command()
async def restart(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  count = 0
  embed = discord.Embed(title="Restart list", description="", color=0x00ff00)
  log_chnl = bot.get_channel(int(log_channel))
  msg = await log_chnl.send(embed=embed)
  for vps in vps_list:
    count += 1
    try:
      ip = vps["ip"]
      username = vps["username"]
      password = vps["password"]
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      shell.run(['screen', '-XS', 'dtsniper', 'quit'], allow_error=True)
      shell.run([
        'screen', '-S', 'dtsniper', '-dm', 'bash', '-c',
        'cd /root/dtsniper/; ./dtsniper'
      ],
                allow_error=True)
      embed.add_field(name=f"VPS {count}", value=f"`Restarted`", inline=True)
      await msg.edit(embed=embed)
    except Exception as e:
      embed.add_field(name=f"VPS {count}", value=f"`{e}`", inline=True)
      await msg.edit(embed=embed)


@bot.command()
@commands.has_permissions(administrator=True)
async def check(ctx, token):
  if not await id_check(ctx.author.id): return
  headers = {'Authorization': token, 'Content-type': 'application/json'}
  r = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
  global r1
  if r.status_code == 401:
    embed = discord.Embed(title=":x: Unauthorized error!",
                          description="Please pass a valid discord token.")
  elif r.status_code == 200:
    data = r.json()
    id = data["id"]
    username = data["username"]
    discriminator = data["discriminator"]
    email = data["email"]
    phone = data["phone"]
    r1 = requests.get(
      "https://discord.com/api/v9/users/@me/applications/521842831262875670/entitlements?exclude_consumed=true",
      headers=headers)
    classic = r1.text.count("Nitro Classic")
    boost = r1.text.count("Nitro Monthly")
    user = await bot.fetch_user(int(id))
    if r1.status_code == 403: locked = True
    elif r1.status_code != 403: locked = False
    embed = discord.Embed(
      title=username + "'s info!",
      description=
      f"**Token** = `{token}`\n\n**ID** = `{id}`\n**Username** = `{username}{discriminator}`\n**Email** = `{email}`\n**Phone** = `{phone}`\n**Nitro Classic Credit** = `{classic}`\n**Nitro Boost Credit** = `{boost}`\n**Locked** = {locked}"
    )
  await ctx.send(embed=embed)


@bot.command()
@commands.has_permissions(administrator=True)
async def stats(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  count = 0
  embed = discord.Embed(title=f"Status",
                        description="Stats from our api",
                        color=0x9824cc)
  msg = await ctx.send(embed=embed)
  for key in DT_APIKEYS:
    count += 1
    stats = requests.get(
      f"https://dtsniper.tech/stats.php?total_servers=").json()
    if not stats["success"]:
      await ctx.send(
        f"Failed to get stats for {key}, make sure the key is valid.")
      embed.add_field(name=f"VPS {count}",
                      value=f"`Failed to get stats`",
                      inline=True)
      await msg.edit(embed=embed)
      continue
    if stats["success"]:
      embed.add_field(
        name=f"VPS {count}",
        value=
        f"Servers: `{stats['total_servers']}`\nAlts:`{stats['alts']}`\nNitro Claimed: `{stats['nitro_claimed']}`\nTime Running: `{stats['time_running']}`",
        inline=True)
      await msg.edit(embed=embed)


@bot.command()
async def failed(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  embed = discord.Embed(title="We missed it", description="", color=0xff0000)
  embed.set_author(name="TZ Sniper")
  embed.add_field(name="**Response**",
                  value="`Gift already redeemed`",
                  inline=True)
  embed.add_field(name="**Response Time**", value="`0.135783s`", inline=True)
  embed.add_field(name="**Guild Name**",
                  value=f"`{ctx.guild.name}`",
                  inline=True)
  embed.add_field(name="**Nitro Sender**",
                  value=f"`{ctx.author}`",
                  inline=True)
  embed.add_field(name="**Nitro Code**",
                  value=f"`YpT67KcBekT4ftqw`",
                  inline=True)
  embed.add_field(name="**Token Ending**", value=f"`Ahf3y`", inline=True)
  embed.add_field(name="**Sniper User**", value=f"`sniper#1234`", inline=True)
  embed.add_field(name="**Sniper Ending**", value=f"`Dyefc`", inline=True)
  await ctx.send(embed=embed)


@bot.command()
async def success(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  embed = discord.Embed(title="Thanks for the nitro hehe!",
                        description="",
                        color=0xff0000)
  embed.set_author(name="TZ Sniper")
  embed.add_field(name="**Response**", value="`Nitro Monthly`", inline=True)
  embed.add_field(name="**Response Time**", value="`0.135783s`", inline=True)
  embed.add_field(name="**Guild Name**",
                  value=f"`{ctx.guild.name}`",
                  inline=True)
  embed.add_field(name="**Sender**", value=f"`{ctx.author}`", inline=True)
  embed.add_field(name="**Nitro Code**",
                  value=f"`YpT67KcBekT4ftqw`",
                  inline=True)
  embed.add_field(name="**Token Ending**", value=f"`Ahf3y`", inline=True)
  embed.add_field(name="**Sniper User**", value=f"`sniper#1234`", inline=True)
  embed.add_field(name="**Sniper Ending**", value=f"`Dyefc`", inline=True)
  await ctx.send(embed=embed)


@bot.command()
async def invitecount(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  count = 0
  embed = discord.Embed(title=f"Invite Count", description="", color=0x9824cc)
  msg = await ctx.send(embed=embed)
  for vps in vps_list:
    count += 1
    try:
      ip = vps["ip"]
      username = vps["username"]
      password = vps["password"]
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      result = shell.run(
        ['bash', '-c', 'cd /root/dtsniper/; wc -l invites.txt'])
      result = result.output.decode("utf-8").split(" ")[0]
      embed.add_field(name=f"VPS {count}",
                      value=f"Invites: `{result}`",
                      inline=True)
      await msg.edit(embed=embed)
    except Exception as e:
      embed.add_field(name=f"VPS {count}",
                      value=f"Failed to get invites\n`{e}`",
                      inline=True)
      await msg.edit(embed=embed)


@bot.command()
async def gettokens(ctx):
  if not await id_check(ctx.author.id):
    return
  await ctx.message.delete()
  embed = discord.Embed(title=f"Total Tokens", description="", color=0xff0000)
  count = 0
  log_chnl = bot.get_channel(int(log_channel))
  msg = await log_chnl.send(embed=embed)
  tokenslist = []
  for vps in vps_list:
    count += 1
    try:
      ip = vps['ip']
      username = vps['username']
      password = vps['password']
      shell = spur.SshShell(hostname=ip,
                            username=username,
                            password=password,
                            missing_host_key=spur.ssh.MissingHostKey.accept)
      with shell.open("/root/dtsniper/tokens.txt") as f:
        lines = f.readlines()
        for line in lines:
          tokenslist.append(line)
      embed.add_field(name=f"VPS {count}",
                      value=f"**{len(lines)}** tokens",
                      inline=False)
      await msg.edit(embed=embed)
    except Exception as e:
      await log(f"Vps {count}", f"Could not get tokens from {ip}\n{e}")
  with open("tokens.txt", "w") as f:
    for token in tokenslist:
      f.write(token)


@bot.command()
async def help(ctx):
  await ctx.message.delete()
  if not await id_check(ctx.author.id):
    embed = discord.Embed(
      title="Help Menu",
      description=
      f"`{prefix}position | view your current position in the queue`")
    await ctx.send(embed=embed)
  else:
    embed = discord.Embed(title="Help Menu",
                          description=f'''
**MAIN COMMANDS**
```
{prefix}queue <@member> <amount> <token> | Add a member to the queue.
{prefix}delete <discordid> | Delete a member from the queue using their discord id.
{prefix}addclaims | Add x amount of claims to a user.
{prefix}removeclaims | Remove x amount of claims from a user.
{prefix}update | Force update the main token.
{prefix}position | View your current position in the queue. (user command)
{prefix}move <@member> <position> | Move user to a specific position in the queue.
{prefix}restart | Restart dtsniper on all VPS.
{prefix}dtsniper | Check if dtsniper is running on all VPS.
{prefix}check <token> | Check a token's info.
{prefix}stats | Check the stats of all VPS.
{prefix}failed | Send a failed snipe embed.
{prefix}success | Send a success snipe embed.
{prefix}invitecount | Check the number of invites on all VPS.
{prefix}invites | Scrapes invites from all snipers
{prefix}gettokens | Scrapes tokens from all snipers
```
**PAYMENT COMMANDS**
```
{prefix}ltc <claims> | Get price of x amount of claims and wallet address.
{prefix}btc <claims> | Get price of x amount of claims and wallet address.
{prefix}eth <claims> | Get price of x amount of claims and wallet address.
{prefix}paypal <claims> | Get price of x amount of claims and paypal email.
```

**SETUP COMMANDS**
```
{prefix}start | Brings the first time setup menu up.
{prefix}embedlog | Sends the queue embed and sets the channel ID.
{prefix}successlog | Sets the success log channel ID.
{prefix}logs | Sets the log channel ID.
{prefix}totalclaimslog | Sends the total claims embed and sets the channel ID.
{prefix}webhooklog | Makes a webhook and sends the url.
{prefix}pinglog <@role> | Sets the ping role.
```
```
{prefix}help | View this menu.
```
''')
    await ctx.send(embed=embed)


# PAYMENT COMMANDS
@bot.command()
@commands.has_permissions(administrator=True)
async def ltc(ctx, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  total = int(amount) * current_claim_price
  await ctx.send(f"Send `{currency}{total}` to {ltc_wallet}")


@bot.command()
@commands.has_permissions(administrator=True)
async def btc(ctx, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  total = int(amount) * current_claim_price
  await ctx.send(f"Send `{currency}{total}` to {btc_wallet}")


@bot.command()
@commands.has_permissions(administrator=True)
async def eth(ctx, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  total = int(amount) * current_claim_price
  await ctx.send(f"Send `{currency}{total}` to {eth_wallet}")
  await ctx.message.delete()


@bot.command()
@commands.has_permissions(administrator=True)
async def paypal(ctx, amount):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  total = int(amount) * current_claim_price
  await ctx.send(f"Send `{currency}{total}` to {paypal_email}")


#Dont need to touch anything below this
@bot.command(alias=['setup'])
async def start(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  embed = discord.Embed(
    title="QueueBot Setup",
    description=
    "Welcome! This bot is designed to help you manage your service. To get started, please follow the steps below."
  )
  embed.add_field(
    name="Step 1",
    value=
    "Create a channel for your queue embed. This is where the queue will be displayed.",
    inline=False)
  embed.add_field(name="Step 2",
                  value="Create a channel for success messages to be sent in.",
                  inline=False)
  embed.add_field(
    name="Step 3",
    value=
    "Create a channel for logs to be sent in (private for you and the bot).",
    inline=False)
  embed.add_field(
    name="Step 4",
    value=
    "Create a channel for webhooks to be sent in (private for you and the bot).",
    inline=False)
  embed.add_field(name="Step 5",
                  value="Create a channel for total claims to be sent in.",
                  inline=False)
  embed.set_footer(text=f"**{prefix}next** for next steps")
  next = await ctx.send(embed=embed)

  def check(m):
    return m.author == ctx.author and m.content == f"{prefix}next"

  msg = await bot.wait_for('message', check=check)
  await msg.delete()
  embed = discord.Embed(title="QueueBot Setup", description="")
  embed.add_field(
    name="Step 1",
    value=f"In the channel for the queue embed type **{prefix}embedlog**",
    inline=False)
  embed.add_field(
    name="Step 2",
    value=
    f"In the channel for the success messages type **{prefix}successlog**",
    inline=False)
  embed.add_field(
    name="Step 3",
    value=
    f"In the channel for the total claims type **{prefix}totalclaimslog**",
    inline=False)
  embed.add_field(name="Step 4",
                  value=f"In the channel for the logs type **{prefix}log**",
                  inline=False)
  embed.add_field(
    name="Step 5",
    value=f"In the channel for the webhooks type **{prefix}webhooklog**",
    inline=False)
  embed.add_field(
    name="Step 6",
    value=
    f"**{prefix}pinglog <@role>** replace @role to the role you want pinged on claim",
    inline=False)
  embed.add_field(name="? ",
                  value=f"**{prefix}next** for next steps",
                  inline=False)
  await next.edit(embed=embed)

  def check(m):
    return m.author == ctx.author and m.content == f"{prefix}next"

  msg = await bot.wait_for('message', check=check)
  await msg.delete()
  embed = discord.Embed(
    title="Finished Setup",
    description=
    "Restart the bot for the values to update.\nAuto deleting in 5 seconds.")
  await next.edit(embed=embed, delete_after=5)


@bot.command()
async def embedlog(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  emb = discord.Embed(title=f"Queue:", description="", colour=0xb24ce1)
  msg = await ctx.send(embed=emb)
  with open('utils.py', 'r') as f:
    lines = f.readlines()
  with open('utils.py', 'w') as f:
    for line in lines:
      if 'queue_message_id' in line:
        f.write(f'queue_message_id = "{msg.id}"\r')
      elif 'queue_channel_id' in line:
        f.write(f'queue_channel_id = "{ctx.channel.id}"\r')
      else:
        f.write(line)
  await log(
    "Queue Embed",
    f"Queue channel ID and message ID have been updated in utils.py\nMessage ID: {msg.id}\nChannel ID: {ctx.channel.id}"
  )


@bot.command()
async def successlog(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  with open('utils.py', 'r') as f:
    lines = f.readlines()
  with open('utils.py', 'w') as f:
    for line in lines:
      if 'success_channel_id' in line:
        f.write(f'success_channel_id = "{ctx.channel.id}"\r')
      else:
        f.write(line)
  await log(
    "Success Channel",
    f"Success channel ID set in utils.py\nChannel ID: <#{ctx.channel.id}>")


@bot.command()
async def logs(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  with open('utils.py', 'r') as f:
    lines = f.readlines()
  with open('utils.py', 'w') as f:
    for line in lines:
      if 'log_channel' in line: f.write(f'log_channel = "{ctx.channel.id}"\r')
      else: f.write(line)
  await log(
    "Log Channel",
    f"Log channel ID set in utils.py\nChannel ID: <#{ctx.channel.id}>")


@bot.command()
async def totalclaimslog(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  embed = discord.Embed(
    title="Total Claims",
    description=f"There already been sniped a total of `0` Nitro!",
    color=0xE67E22)
  msg = await ctx.send(embed=embed)
  with open('utils.py', 'r') as f:
    lines = f.readlines()
  with open('utils.py', 'w') as f:
    for line in lines:
      if 'totalsnipeschannel' in line:
        f.write(f'totalsnipeschannel  = "{ctx.channel.id}"\r')
      elif 'totalsnipesmessage' in line:
        f.write(f'totalsnipesmessage = "{msg.id}"\r')
      else:
        f.write(line)
  await log(
    "Total Claims Channel",
    f"Total Claims channel ID set in utils.py\nChannel ID: <#{ctx.channel.id}>"
  )


@bot.command()
async def webhooklog(ctx):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  webhook = await ctx.channel.create_webhook(name="QueueBot")
  embed = discord.Embed(
    title="Webhook Created",
    description=
    f"Place this inside of the config.toml file in, **webhookNitroFailed** AND **webhookNitroClaimed**\n{webhook.url}",
    color=0x00ff00)
  await ctx.send(embed=embed)


@bot.command()
async def pinglog(ctx, role):
  if not await id_check(ctx.author.id): return
  await ctx.message.delete()
  with open('utils.py', 'r') as f:
    lines = f.readlines()
  with open('utils.py', 'w') as f:
    for line in lines:
      if 'claim_ping_id' in line: f.write(f'claim_ping_id = "{role}"\r')
      else: f.write(line)


async def log(title, description):
  try:
    log_chnl = bot.get_channel(int(log_channel))
    embed = discord.Embed(title=title,
                          description=description,
                          colour=0xb24ce1)
    await log_chnl.send(embed=embed)
  except:
    print(f"{title}\n{description}")


@bot.event
async def on_command_error(ctx, error):
  if isinstance(error, CommandNotFound): return


bot.run(token)
