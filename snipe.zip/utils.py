import aiosqlite
import os

# do -embedlog to automatically set the id and send the queue embed
# do -sucesslog to automatically set the channel id
# do -logs to automatically set the channel id
# do -pinglog @role to automatically set the claim ping role
# do -totalclaimslog to automatically set the id and send the total claims embed

token = os.environ['TOKEN']
prefix = "-"

queue_channel_id = "1079035488217858088"
queue_message_id = "1079036396725092393"
success_channel_id = "1079035554613706803"
log_channel = ""
claim_ping_id = "<@&1079036982405115954>"totalsnipeschannel = "1079035675371917403"
totalsnipesmessage = "1079036906953781369"
#API KEYS
DT_APIKEYS = [""]

#if the queue is empty your token will be placed in queue until you add someone to it.
your_own_token = "OTE5NjM2OTA0NTE1ODY2NjQ0.GJpBRC.qyUicCw_Sbja2iDFkBc-9Kg1i6va5aODeWA7No"

admin_ids = [
  "1070057998791217162", "521964331341053963"
]  # place your discord id in the admin_ids list to use the commands

vps_list = [
  {
    "ip": "46.101.89.152",
    "username": "root",
    "password": "sX29kdfka2sz"
  },
]

current_claim_price = 0.65
btc_wallet = "bc1qwpjumdm5npk74rvlt0rwl7mplg9avmfl8ad7zd"
eth_wallet = "0x79EeD40FE27B4a4a5C314ba4b203d52368492Fba"
ltc_wallet = "LPoMAAmk7RkU2XHNQMg9cUJztJsfGHb7RR"
paypal_email = ""
currency = "$"

custom_dm_message = "Thank you for buying our sniping services, your claims have been succesfully delivered. Please leave a review in <#1070067961160810569> if you enjoyed our servive. See you next time! <3"

# emojis to use in the success message
boost_emoji = "<:10700395688139162831:1078043882178228326>"
classic_emoji = "<a:10701330271596749321:1078043915053183006>"
# emojis will be displayed in the queue embed
currently_claiming_emoji = "<a:boomclaim:1078043990877810871>"
currently_waiting_emoji = "<a:waiting:1078043975967051787>"

# in check_tokens if the token is invalid it will automatically remove it from the database
remove_invalid_tokens = True


async def id_check(id):
  if str(id) in admin_ids:
    return True
  else:
    return False


async def update_positions():
  async with aiosqlite.connect("q.db") as db:
    cursor = await db.execute("SELECT position FROM queue ORDER BY position")
    rows = await cursor.fetchall()
    await cursor.close()
    rows = [x[0] for x in rows]
    i = 0
    for row in rows:
      i += 1
      await db.execute("UPDATE queue SET position = ? WHERE position = ?",
                       (i, row))
      await db.commit()
